﻿namespace IdiomaMario
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }

        // Método para el botón "Insertar" para Idioma 1
        public async void OnInsertarEspanolClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(EntryEspanol.Text))
            {
                string nivel = await DisplayPromptAsync("Nivel de Español", "¿Cuál es tu nivel?", "Aceptar", "Cancelar", "A, B o M");

                if (!string.IsNullOrWhiteSpace(nivel))
                {
                    EntryEspanol.Text = nivel.ToUpper();
                }
            }
        }

        // Método para el botón "Insertar" para Idioma 2
        public async void OnInsertarInglesClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(EntryIngles.Text))
            {
                string[] niveles = { "A", "B", "M" };
                string nivel = await DisplayActionSheet("Selecciona el nivel para Inglés", "Cancelar", null, niveles);

                if (!string.IsNullOrWhiteSpace(nivel) && nivel != "Cancelar")
                {
                    EntryIngles.Text = nivel.ToUpper();
                }
            }
        }

        // Método para el botón "Insertar" para Idioma 3
        public async void OnInsertarFrancesClicked(object sender, EventArgs e)
        {
            string seleccion = await DisplayActionSheet("Selecciona el nivel para Francés", "Cancelar", "Borrar", "A", "B", "M");

            if (seleccion == "Borrar")
            {
                EntryFrances.Text = string.Empty;
            }
            else if (seleccion != "Cancelar")
            {
                EntryFrances.Text = seleccion.ToUpper();
            }
        }

        // Método para el botón "Comprobar"
        public async void OnComprobarNivelesClicked(object sender, EventArgs e)
        {
            if (!await DisplayAlert("Confirmación", "¿Deseas ver el número de idiomas avanzados?", "Sí", "No"))
            {
                EtiquetaMensaje.Text = string.Empty;
                return;
            }

            int contadorAvanzados = new[] { EntryEspanol.Text, EntryIngles.Text, EntryFrances.Text }
                                    .Count(idioma => idioma == "A");

            BotonNivelAvanzado1.IsEnabled = (contadorAvanzados >= 1);
            BotonNivelAvanzado2.IsEnabled = (contadorAvanzados >= 2);
            BotonNivelAvanzado3.IsEnabled = (contadorAvanzados == 3);

            EtiquetaMensaje.Text = contadorAvanzados > 0 ? $"Idiomas avanzados: {contadorAvanzados}" : string.Empty;
        }

        public void OnVerCreditosClicked(object sender, EventArgs e)
        {
            DisplayAlert("Créditos", "Desarrollado por: Mario", "Aceptar");
        }
    }
}
